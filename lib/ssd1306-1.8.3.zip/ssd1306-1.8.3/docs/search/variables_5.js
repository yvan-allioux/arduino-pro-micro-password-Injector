var searchData=
[
  ['glyph',['glyph',['../struct_s_char_info.html#a63babb0e12a4d2b08ececeb39abb6ed0',1,'SCharInfo']]],
  ['glyph_5fsize',['glyph_size',['../struct_s_fixed_font_info.html#a16b1ae2c599c2e8c1634a372f4c550b8',1,'SFixedFontInfo']]]
];
